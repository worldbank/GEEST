from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QButtonGroup
from qgis.core import Qgis
from qgis.PyQt.QtCore import pyqtSignal
from .combined_widget_factory import CombinedWidgetFactory
from geest.utilities import log_message


class IndicatorConfigurationWidget(QWidget):
    """
    Widget for configuring indicators based on a dictionary.
    """

    data_changed = pyqtSignal()

    def __init__(self, attributes: dict) -> None:
        super().__init__()
        # This is a reference to the attributes dictionary
        # So any changes made will propogate to the JSONTreeItem
        self.attributes = attributes
        self.layout: QVBoxLayout = QVBoxLayout()
        self.button_group: QButtonGroup = QButtonGroup(self)

        try:
            self.create_radio_buttons(attributes)
        except Exception as e:
            log_message(f"Error in create_radio_buttons: {e}", level=Qgis.Critical)
            import traceback

            log_message(traceback.format_exc(), level=Qgis.Critical)

        self.setLayout(self.layout)

    def create_radio_buttons(self, attributes: dict) -> None:
        """
        Uses the factory to create radio buttons from attributes dictionary.
        """

        analysis_mode = attributes.get("analysis_mode", "")
        # We iterate over a list to defend against changes to the dictionary
        # See issue #620. This is a workaround until we can refactor the code
        # The issue is that the dictionary is being modified while we are iterating over it
        # by the safety_polygon_configuration_widget.py file I think.
        for key, value in list(attributes.items()):
            radio_button_widget = CombinedWidgetFactory.create_radio_button(
                key, value, attributes
            )
            if radio_button_widget:
                if key == analysis_mode:
                    radio_button_widget.setChecked(True)
                # Special case for "Do Not Use" radio button
                if (
                    key == "indicator_required"
                    and value == 0
                    and analysis_mode == "Do Not Use"
                ):
                    radio_button_widget.setChecked(True)
                self.button_group.addButton(radio_button_widget)
                self.layout.addWidget(radio_button_widget.get_container())
                radio_button_widget.data_changed.connect(self.update_attributes)

    def update_attributes(self, new_data: dict) -> None:
        """
        Updates the attributes dictionary with new data from radio buttons.
        """
        # log_message(f"Updating attributes dictionary with new data: {new_data}")
        # In the ctor of the widget factor we humanise the name
        # now we roll it back to the snake case version so it matches keys
        # in the JSON data model
        snake_case_mode = (
            self.button_group.checkedButton().label_text.lower().replace(" ", "_")
        )
        new_data["analysis_mode"] = snake_case_mode
        self.attributes.update(new_data)
        # log_message(f"Updated attributes dictionary: {self.attributes}")
        self.data_changed.emit()
