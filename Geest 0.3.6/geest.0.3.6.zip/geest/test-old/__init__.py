"""
import qgis libs so that we set the correct sip api version
"""

import qgis  # NOQA
